package kr.or.lis.vo;

public class FolderVO {
	private int fol_no;
	private String fol_name;
	private String ml_no;
	
	public int getFol_no() {
		return fol_no;
	}
	
	public void setFol_no(int fol_no) {
		this.fol_no = fol_no;
	}
	
	public String getFol_name() {
		return fol_name;
	}
	
	public void setFol_name(String fol_name) {
		this.fol_name = fol_name;
	}
	
	public String getMl_no() {
		return ml_no;
	}
	
	public void setMl_no(String ml_no) {
		this.ml_no = ml_no;
	}
}
