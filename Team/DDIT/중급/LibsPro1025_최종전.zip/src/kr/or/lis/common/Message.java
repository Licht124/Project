package kr.or.lis.common;

public class Message {
    private String result;

    public Message() {
    }

    public Message(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
