package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import controller.Controller;
import dao.UserDAO;
import util.ScanUtil;
import util.View;

public class UserService {

	private static UserService instance=null;
	private UserService() {}
	public static UserService getInstance() {
		if(instance==null) instance=new UserService();
		return instance;
	}
	
	UserDAO dao=UserDAO.getInstance();
	
	//회원로그인 메뉴	
	public int loginMenu() {
		System.out.println("\n============= 회원 화면입니다. 번호를 선택하세요. ==============");
		System.out.println("1.운동추천 \n2.상품구매 \n3.락커이용 \n4.BMI계산 \n5.로그아웃");
		System.out.println("=====================================================");
		System.out.print("번호입력 >> ");
		switch(ScanUtil.nextInt()) {
		case 1:
			return View.EXERCISE_RECOMMAND_MENU;
		case 2:
			return View.BUY_MENU;
		case 3:
			return View.LOCKER_MENU;
		case 4:
			return View.BMI_MENU;
		case 5: 
			System.out.println("로그 아웃 되었습니다");
			Controller.sessionStorage.put("login", false);
			Controller.sessionStorage.put("loginInfo", null);
			return View.HOME;
		default :
			System.out.println("\n[상태메세지]");
			System.out.println("\n 번호를 다시입력하세요.");
			return View.USER_MENU;
		}
		}
		
	//회원가입
	public int signUp() {
		System.out.println("-----------------------------------------------------");
		System.out.println("\n[ 회원등록  ]");
		System.out.print("▶아이디 : ");
		String id=ScanUtil.nextLine();
		
		System.out.print("▶비밀번호 : ");
		String pw=ScanUtil.nextLine();

		System.out.print("▶이름 : ");
		String name=ScanUtil.nextLine();
		
		System.out.print("▶Email : ");
		String mail=ScanUtil.nextLine();
		
		System.out.print("▶핸드폰번호 : ");
		String phone=ScanUtil.nextLine();

		System.out.print("▶성별(F|M) : ");
		String gen=ScanUtil.nextLine();	

		List<Object> param = new ArrayList<>();
		param.add(id);
		param.add(pw);
		param.add(name);
		param.add(mail);
		param.add(phone);
		param.add(gen);
		
		int result=dao.signUp(param);
		if(result>0) {
			System.out.println("\n[상태메세지]\n회원가입이 완료되었습니다. 메인화면으로 돌아갑니다\n");
		}else {
			System.out.println("[오류메세지]\n회원가입 실패!!\n");
		}
	    return View.HOME; ///////////////로그인화면??
			
	}
}
