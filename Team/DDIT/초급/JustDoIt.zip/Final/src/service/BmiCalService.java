package service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import controller.Controller;
import dao.ExerciseRcDAO;
import part.Abdomen;
import part.Arm;
import part.Back;
import part.Chest;
import part.Shoulder;
import part.LowerBody;
import util.PrintUtil;
import util.ScanUtil;
import util.View;

public class BmiCalService 
{
	private static BmiCalService instance = null;
	
	private BmiCalService() {}
	
	public static BmiCalService getInstance() 
	{
		if(instance == null) instance = new BmiCalService();
		return instance;
	}
	
	public int calBmi()
	{
	
		while(true)
		{
			System.out.println("\n============ 체질량 지수(BMI) 계산 화면입니다. ===============");
			System.out.println("=====================================================");
			
			//BMI지수= 몸무게(kg) ÷ (신장(m) × 신장(m))
			//BMI지수= 몸무게(kg) ÷ ((신장(cm) × 신장(cm)/10000))
			
			System.out.print("키(cm) 입력 >> ");
			String height = ScanUtil.nextLine();
			
			 if(!ScanUtil.isDouble(height)) 	// 입력값이 문자면
			 {
				 System.out.println("잘못 입력하셨습니다."); 
				 return View.BMI_MENU;		  
			 }
			
			
			System.out.print("체중(kg) 입력 >> ");
			String weight = ScanUtil.nextLine();
			
			 if(!ScanUtil.isDouble(weight)) 	// 입력값이 문자면
			 {
				 System.out.println("잘못 입력하셨습니다."); 
				 return View.BMI_MENU;		  
			 }
			
			
			double bmi;
			
			bmi = Double.parseDouble(weight)/((Double.parseDouble(height) * Double.parseDouble(height))/10000);
		
			System.out.printf("계산된 체질량 지수(BMI)는 다음과 같습니다 : %.2f",bmi);
			System.out.println("\n=====================================================");
			
			return View.USER_MENU;
			
		}

		
	}
}



