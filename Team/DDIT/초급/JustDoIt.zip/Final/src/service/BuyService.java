package service;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import controller.Controller;
import dao.BuyDAO;
import util.PrintUtil;
import util.ScanUtil;
import util.View;

public class BuyService {
	private static BuyService instance = null;

	private BuyService() {}
	
	public static BuyService getInstance() {
		if (instance == null)
			instance = new BuyService();
		return instance;
	}

	BuyDAO dao = BuyDAO.getInstance();

	List<Object> orderParam=new ArrayList<>
	(Arrays.asList(" "," "," "," "," "," "));
	
	List<Object> orderDetParam=new ArrayList<>
	(Arrays.asList(" "," "," "," "," "));
	
	List<Object> prodParam=new ArrayList<>  // 수량 값만 전달
	(Arrays.asList(" "," "));
	
	int price = 0 ;
	int qty = 1;
	int stock = 0;
	int prodNo = 0 ;
	

	List<Map<String, Object>> list = new ArrayList<>();
	String selProdNo = "";
	
	public int selectMenu() {
		 price = 0 ;  
		 qty = 1;     
		 stock = 0;   
		 prodNo = 0 ; 
		
		System.out.println("\n==============상품구매 화면입니다. 번호를 선택하세요.==============");

		list = dao.selectMenu();

		// 카테고리명  출력
		for (Map<String, Object> item : list) 
		{
			System.out.print(item.get("CAT_NO") + "." + item.get("CAT_NAME"));
			System.out.println();
		}
		
		System.out.println("9.구매내역");
		System.out.println("0.뒤로가기");
		System.out.println("=====================================================");
		System.out.print("조회 할 목록 번호 >> ");
		String menu = ScanUtil.nextLine();
		

		if(!ScanUtil.isInteger(menu)) // 문자일경우
		{
			System.out.println("\n숫자를 입력하세요\n");
			return View.BUY_MENU;
		}
				
		while(true)
		{
			switch (Integer.parseInt(menu))
			{
				case 0:
					return View.USER_MENU;
				case 1:
					buyItem(1); // 이용권
					return View.BUY_MENU;
				case 2:
					buyItem(2); // 헬스용품
					return View.BUY_MENU;
				case 3:
					buyItem(3); // 식품
					return View.BUY_MENU;
				case 9:
					showBuyList();
					return View.BUY_MENU;
				default:
					System.out.println("다시 입력해주세요");
			}
			
		return View.BUY_MENU;
		}
	}
	
	
	public int buyItem(int itemType)
	{
		if(selProd(itemType)== View.BUY_MENU) 	{ return View.BUY_MENU; }
		
		if(itemType == 2 || itemType == 3)
		{	
			if(selQty(list,selProdNo)== View.BUY_MENU) 	{ return View.BUY_MENU; }
		}
		
		if(chkBuy(list,selProdNo)== View.BUY_MENU) 	{ return View.BUY_MENU; }
		if(selPayOption(list,selProdNo) == View.BUY_MENU) 	{ return View.BUY_MENU; }
		
		dbSet();
		return View.BUY_MENU;
	}
	
	public int selProd(int prodKind)
	{
		while(true)
		{
			switch(prodKind)
			{
			case 1:
				System.out.println("\n       [이용권 목록]");
				System.out.println("-------------------------------------------------");
				System.out.println("                   이용권 종류\t            가격");
				System.out.println("-------------------------------------------------");
				list = dao.selTicket();
				break;

			case 2:
				System.out.println("\n       [헬스용품 목록]");
				System.out.println("-------------------------------------------------");
				System.out.println("                   헬스용품 종류\t          가격");
				System.out.println("-------------------------------------------------");
				list = dao.selTool();
				break;

			case 3:
				System.out.println("\n       [식품 목록]");
				System.out.println("-------------------------------------------------");
				System.out.println("                   식품 종류\t          가격");
				System.out.println("-------------------------------------------------");
				list = dao.selFood();
				break;	
			default:
				return View.BUY_MENU;
				
			}

		for (int i = 0; i < list.size(); i++) 
		{
			System.out.print("상품번호 :" + (list.get(i).get("PROD_NO")) +  ". " + (list.get(i).get("PROD_NAME")) + "\t가격 : " + (list.get(i).get("PROD_PRICE")));
			System.out.println();
		}
		System.out.println("-------------------------------------------------");
		
	
			System.out.print("▶구매 할 상품 번호 입력 : ");
			selProdNo = ScanUtil.nextLine();
			
						
			if(!ScanUtil.isInteger(selProdNo)) // 문자일경우
			{
				System.out.println("\n숫자를 입력하세요\n");
				return View.BUY_MENU;
			}
			
			for (int i = 0; i < list.size(); i++) 
			{
				if(selProdNo.equals(String.valueOf(list.get(i).get("PROD_NO"))))
				{
					 System.out.println();
					prodNo = Integer.valueOf(String.valueOf(list.get(i).get("PROD_NO")));
					System.out.println(list.get(i).get("PROD_NAME") + "을 선택하셨습니다. " +"(단가 : "+ list.get(i).get("PROD_PRICE")+"원)");
					price = Integer.valueOf(String.valueOf(list.get(i).get("PROD_PRICE")));  // 검증 필요
					return 1;
				}	
			}
			
			//상품번호 찾지 못한 경우
			System.out.println("해당 상품을 찾을 수 없습니다.다시 입력해주세요");
			return View.BUY_MENU;

		}
				//오타 입력 처리 필요
	}
	


	public int selQty(List<Map<String, Object>> list,String selProdNo) 
	{ 
	
		while(true)
		{
			System.out.print("구매 할 수량 선택 : ");
			String selQty = ScanUtil.nextLine();
			
			if(!ScanUtil.isInteger(selQty)) // 문자일경우
			{
				System.out.println("\n숫자를 입력하세요\n");
				return View.BUY_MENU;
			}
			
			
			for (int i = 0; i < list.size(); i++) 
			{
				if(selProdNo.equals(String.valueOf(list.get(i).get("PROD_NO"))))
				{
					orderDetParam.set(3,selQty); 
					prodParam.set(0, selQty);
					qty = Integer.parseInt(selQty);  // qwd
					stock = Integer.valueOf(String.valueOf(list.get(i).get("PROD_STOCK")));
					return 1;	
				}
			}
		}
		
	}
	
			
	public int chkBuy(List<Map<String, Object>> list,String selProdNo) 
	{ 
		int allPrice = price * qty;
		while(true)
		{
			System.out.print("총 결제 금액은 " + allPrice + "원 입니다 구매하시겠습니까? [Y / N] >>");
			String selBuy = ScanUtil.nextLine();
			
			if(ScanUtil.isInteger(selBuy)) // 숫자일경우
			{
				System.out.println("Y / N 중 하나를 입력하세요");
				return View.BUY_MENU;
			}
			if(selBuy.toUpperCase().equals("Y"))
			{
				//하기전 데이터 셋팅 필요
				orderParam.set(3,allPrice); 
				return 1;
			}
			else if(selBuy.toUpperCase().equals("N"))
			{
				System.out.println("\n구매 취소를 선택하셨습니다. 구매 목록으로 돌아갑니다.\n");

				return View.BUY_MENU;
			}
			else if(!selBuy.toUpperCase().equals("Y") && !selBuy.toUpperCase().equals("N"))
			{
				System.out.println("Y / N 중 하나를 입력하세요");
				return View.BUY_MENU;
			}
		}
	
		
	}
	
//	public int addItem(List<Map<String, Object>> list,String selProdNo) 
//	{ 
//		System.out.println("장바구니에 담겼습니다.추가 구매 하시겠습니까?");
//		String selBuy = ScanUtil.nextLine();
//		
//		if(selBuy.toUpperCase().equals("Y"))
//		{
//			//하기전 데이터 셋팅 필요
//			orderParam.set(3,allPrice); 
//		}
//
//	}
//		
		
	
	public int selPayOption(List<Map<String, Object>> list,String selProdNo) 
	{ 
		while(true)
		{
			System.out.println("\n결제 방식을 선택 해주세요 : ");
		
			System.out.println("1.카드");
			System.out.println("2.현금");
			System.out.print("번호입력 >>");
			String selPayOption = ScanUtil.nextLine();
			
			if(!ScanUtil.isInteger(selPayOption)) // 문자일경우
			{
				System.out.println("1,2 중 하나를 입력하세요");
				return View.BUY_MENU;
			}
			
			else if(selPayOption.equals("1"))
			{
				selPayOption = "카드";
			}
			else if(selPayOption.equals("2"))
			{
				selPayOption = "현금";
			}
			
			else
			{
				System.out.println("1,2 중 하나를 입력하세요");
				return View.BUY_MENU;
			}
			

			String orderStatus = "결제완료";
			if(selPayOption.equals("카드") || selPayOption.equals("현금")) 
			{
				System.out.println(selPayOption + "을 투입구에 넣어주세요.");
				System.out.println("3..\n2..\n1..");
				System.out.println("결제가 완료되었습니다. 이용해주셔서 감사합니다.\n");
				orderParam.set(4,orderStatus); 
				orderParam.set(5,selPayOption);
				prodParam.set(0, stock - qty);
				prodParam.set(1, prodNo);
				return 1;
			}
		
		return 1;
		}
		
	}
	
	
	public void dbSet()
	{
		 Map<String, Object> result=dao.selectCnt();
	      Object val = result.get("COUNT(*)");
	      String res = String.valueOf(val);
	      
	      
	      List<Map<String, Object>> list = new ArrayList<>();
	      list=dao.selectOrders();
	      
	      int ordersEndNo = 0;
	      
	      if(res.equals("0")) 
	        {
	         ordersEndNo += 1;
	        }
	       else
	        {
	           for (int i = 0; i < list.size(); i++) 
	            {
	               ordersEndNo =Integer.valueOf(String.valueOf(list.get(i).get("ORDERS_NO")));
	            }
	            
	            ordersEndNo += 1;
	        }
	      
	      
	      orderParam.set(0,ordersEndNo);
	      orderParam.set(1,Controller.sessionStorage.get("loginInfo"));
	      
	      LocalDate now = LocalDate.now();
	      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy/MM/dd");
	      String formatedNow = now.format(formatter);
	   
	      orderParam.set(2,formatedNow);
	      //ORDERS_NO,USERS_ID,ORDERS_DATE
	      dao.insOrderData(orderParam);
	      
	      //ORDERDET_NO, ORDERS_NO, ORDERDET_QTY, ORDERDET_PRICE
	      
	        orderDetParam.set(0,ordersEndNo); orderDetParam.set(1,orderParam.get(0));
	        orderDetParam.set(2,selProdNo); orderDetParam.set(3,qty);
	        orderDetParam.set(4,price); 
	        dao.insOrderDetData(orderDetParam);
	        
	        dao.updateProdStockData(prodParam);
	  
	}

	public int showBuyList()
	{
		List<Map<String,Object>> result=null;
		
		System.out.println("-------------------------------------------------");
		System.out.println("[구매 내역 조회]");
		
		String id;
		id = (String)Controller.sessionStorage.get("loginInfo");
		
		result=dao.selectAll();
		
			if(result != null)
			{
				PrintUtil.printf("%15o %25o %25o %25o %25o", " ", "회원 아이디", "주문일자", "총 결제금액", "결제여부", "결제수단");
				System.out.println();
				System.out.println("=========================================================");
				for(int i=0; i<result.size(); i++) {
		
					String date =String.valueOf(result.get(i).get("ORDERS_DATE")).substring(0,10);
				
					PrintUtil.printf("%5o"," ",result.get(i).get("USERS_ID"));
					PrintUtil.printf("%15o"," ",date);
					PrintUtil.printf("%10o"," ",result.get(i).get("ORDERS_PRICE"));
					PrintUtil.printf("%15o"," ",result.get(i).get("ORDERS_STATUS"));
					PrintUtil.printf("%15o"," ",result.get(i).get("ORDERS_PAYOPTION"));
					
					System.out.println();
										
				}
			}
			else
			{
				System.out.println("\n구매 내역이 확인되지 않습니다.");
			}
				
				return View.BUY_MENU;	
	}

}
