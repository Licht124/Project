package service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.Arrays;


import dao.AdminDAO;
import util.ScanUtil;
import util.View;

public class AdminService {
	
	private static AdminService instance=null;
	private AdminService() {}
	public static AdminService getInstance() {
		if(instance==null) instance=new AdminService();
		return instance;
	}
	
	AdminDAO dao=AdminDAO.getInstance();
	int pagNo=0;
	
	
	// 관리자로그인 메뉴
	public int loginMenu() {
		System.out.println("\n============= 관리자 화면입니다. 번호를 선택하세요. ==============");
		System.out.println("1.회원정보 조회  \n2.회원관리  \n3.매출정보 조회  \n4.이전단계"); 
		System.out.println("=====================================================");
		System.out.print("번호입력 >> ");
		switch(ScanUtil.nextInt()) {
		case 1 :
			return View.ADMIN_USERLIST;
		case 2 :
			return View.ADMIN_EDITINFO;
		case 3 :
			return View.ADMIN_SALES;
		case 4 :
			return View.HOME;
			default : 
			System.out.println();
			System.out.println("[상태메세지]");
			System.out.println(" 번호를 다시 입력하세요.");
			System.out.println();
		}
		
		return View.HOME;
	}
	
	// (1)회원정보 조회
	public int userList() {
		
		List<Map<String, Object>> userList=dao.userListNum();
		
		if(userList==null) {
			System.out.println();
			System.out.println("[상태메세지]");
			System.out.println("회원이 존재하지 않습니다.\n");
			System.out.println();
		}else {
			System.out.println("-----------------------------------------------------");
			System.out.println("[ 회원목록  ]");
			for(Map<String,Object> user : userList) {
				System.out.print(user.get("NUM")+ ". ");
				System.out.print(user.get("USERS_ID"));
				System.out.print("\t"+user.get("USERS_NAME"));
				System.out.print("\t"+user.get("USERS_EMAIL"));
				System.out.print("\t"+user.get("USERS_PHONE"));
				System.out.println("\t"+user.get("USERS_GENDER"));
			}
		}
		System.out.println("-----------------------------------------------------");
		System.out.println("1.회원관리   2.이전단계");
		System.out.print("번호 입력 >> ");
		
		switch(ScanUtil.nextInt()) {
		case 1:
			return View.ADMIN_EDITINFO;
		case 2:
			return View.ADMIN_MENU;
		default : 
			System.out.println("\n[상태메세지]");
			System.out.println(" 번호를 다시 입력하세요.");
			return View.ADMIN_USERLIST;
	     }
	}
	
	// (2)회원메뉴/회원등록
	public int editInfo() {
		//System.out.println("-------------------------------------------");
		System.out.println("\n==============회원관리 화면입니다. 번호를 선택하세요.==============");
		System.out.println("1.회원등록 \n2.회원수정 \n3.회원삭제 \n0.이전메뉴");
		System.out.println("=====================================================");
		System.out.print("번호입력 >> ");
		switch(ScanUtil.nextInt()) {
		case 1:
			return View.USER_SIGNUP;
		case 2:
			editUser();
			return View.ADMIN_EDITINFO;
		case 3:
			deleteUser();	
			return View.ADMIN_EDITINFO;
		default:
			break;
		}return View.ADMIN_MENU;
				
	}
	// (2)회원수정
	public int editUser() 
	{
      //전체회원띄우기
		List<Map<String, Object>> userList=dao.userListNum();		
		if(userList==null) 
		{
			System.out.println("회원이 존재하지 않습니다.");
		}else 
		{
			System.out.println("-----------------------------------------------------");
			System.out.println("[ 회원목록  ]");
			for(Map<String,Object> user : userList) 
			{
				System.out.print(user.get("NUM")+ ". ");
				System.out.print(user.get("USERS_ID"));
				System.out.print("\t"+user.get("USERS_NAME"));
				System.out.print("\t"+user.get("USERS_EMAIL"));
				System.out.print("\t"+user.get("USERS_PHONE"));
				System.out.println("\t"+user.get("USERS_GENDER"));
			}
			System.out.println("-----------------------------------------------------");
		    System.out.println("<<<수정할 회원아이디를 입력하세요>>>");		    
		   
		    System.out.print("▶아이디 : ");
	    	String id = ScanUtil.nextLine();
	    	
	    	Map<String, Object> result=dao.userListID(id);

			
			if(result==null)
			{
				System.out.println("\n[오류메세지]");
				System.out.println(" 아이디가 존재하지않습니다. 아이디를 다시입력하세요.\n");
				return View.ADMIN_EDITUSER; ////////// 리턴값 ADMIN_EDITINFO
			}
			else if(result.get("USERS_ID").equals(id)) 
			{
		
				System.out.println("\n<<<회원정보 수정>>>");
	
				System.out.print("▶ 회원명 : ");
				String name=ScanUtil.nextLine();			
	
				System.out.print("▶ 이메일 : ");
				String mail=ScanUtil.nextLine();
		
				System.out.print("▶ 핸드폰번호 : ");
				String phone=ScanUtil.nextLine();		
		
				System.out.print("▶ 성별(F/M) : ");
				String gen=ScanUtil.nextLine();
		
		List<Object> param = new ArrayList<>();			
		param.add(name);
		param.add(mail);
		param.add(phone);
		param.add(gen);
		param.add(id);
		
		int result1=dao.edit(param);
		
		if(result1>0) 
		{
			System.out.println("\n[상태메세지]\n 회원정보 수정이 완료되었습니다.관리자화면으로 돌아갑니다.");
			return View.ADMIN_MENU;
		}else 
		{
			System.out.println("[오류메세지]\n 회원정보 수정 실패!!");
		}return View.ADMIN_MENU;
			}
		}
		return View.ADMIN_MENU;
	}
	
	// (2)회원삭제
	public int deleteUser() {
		 System.out.println("\n<<<삭제할 회원아이디를 입력하세요>>>");
		 System.out.print("▶아이디 : ");
	    String id = ScanUtil.nextLine();
			
		List<Object> param = new ArrayList<>();			
		param.add(id);

		int result=dao.delete(param);
		if(result>0) {
				System.out.println("\n[상태메세지]\n 회원삭제가 완료되었습니다. 관리자화면으로 돌아갑니다.\n");
				return View.ADMIN_MENU; ////////// 리턴값 ADMIN_EDITINFO ★★
		}else {
			System.out.println("\n[상태메세지]\n 아이디가 존재하지 않습니다.\n");
		}
	    return View.ADMIN_MENU; ////////// 리턴값 ADMIN_EDITINFO
	}
	
	

	
	// (3)매출조회
	public int sales() {
		// 총매출
		Map<String,Object> result=dao.total();
		Object value=result.get("SUM(ORDERS_PRICE)");
		String res=String.valueOf(value);
		
		System.out.println("---------------------------------------------------");
		System.out.println("[ 매출 현황  ]\n▶총 매출액              "+res+"원");
		
		// 금일매출
		Map<String,Object> result1=dao.todayTotal();
		Object value1=result1.get("SUM(ORDERS_PRICE)");
		String res1=String.valueOf(value1);	
		
		if(res1.equals("null"))
		{
			System.out.println("▶금일 매출액           0원 ");
		}
		else
		{
		System.out.println("▶금일 매출액           "+res1+"원 ");
		}
		
		// 카테고리별 매출
		System.out.println("▶카테고리별 매출액");
		Map<String, Object> result21=dao.catTotal1();
		Object value21=result21.get("SUM(ORDERDET_PRICE)");
		String res21=String.valueOf(value21);
		
		Map<String, Object> result22=dao.catTotal2();
		Object value22=result22.get("SUM(ORDERDET_PRICE)");
		String res22=String.valueOf(value22);
		
		Map<String, Object> result23=dao.catTotal3();
		Object value23=result23.get("SUM(ORDERDET_PRICE)");
		String res23=String.valueOf(value23);
		
		System.out.println("   - 이용권         "+res21+"원");
		System.out.println("   - 헬스용품      "+res22+"원");
		System.out.println("   - 식품            "+res23+"원");
				
		return View.ADMIN_SALES_DETAIL;
	}
	
	// (3)매출조회-상품별
	public int salesDetail() {
		System.out.println("\n==============상세목록 화면입니다. 번호를 선택하세요.==============");
		System.out.println("1.이용권 \n2.헬스용품 \n3.식품");
		System.out.println("=====================================================");
		System.out.print("번호선택 >> ");
		String num=ScanUtil.nextLine();
		
		List<Object> param=new ArrayList<Object>();
		param.add(num);
		
		List<Map<String, Object>>  result=dao.detailTotal(param); 
		System.out.println("-----------------------------------------------------");
		System.out.println("[ 상세품목  ]");
		System.out.println("품번    품명   판매수량   판매금액");
		
		for(int i=0; i<result.size(); i++) {
			System.out.print(result.get(i).get("PROD_NO") + ".");
			System.out.print("\t"+result.get(i).get("PROD_NAME"));
			System.out.print("\t"+result.get(i).get("판매수량")+"개");
			System.out.println("\t"+result.get(i).get("판매금액")+"원");
		}
		System.out.println("-----------------------------------------------------");
		System.out.println("1.관리자메뉴 2.메인메뉴 ");
		System.out.print("번호선택 >> ");
		
		switch(ScanUtil.nextInt()) { 
		case 1 :
			return View.ADMIN_MENU;
		case 2 :
			return View.HOME;
		}
	return View.HOME;
}
	
	
	
	
	// (4)재고 관리(조회,추가,수정,삭제)
		public int stock() {
		return 0;
		}
	
	
	
		
}
