package service;

import java.util.Map;

import controller.Controller;
import dao.LoginDAO;
import util.ScanUtil;
import util.View;

public class LoginService {
	// 싱글톤 패턴을 만든다.
	private static LoginService instance = null;
	private LoginService() {}
	public static LoginService getInstance() {
		if(instance == null) 
			instance = new LoginService();
		return instance;
	}
	
	LoginDAO dao=LoginDAO.getInstance();
	int pagNo=0;

	
	//회원 로그인
	public int login() {
		System.out.print("\n▶아이디 입력 : ");
		String id=ScanUtil.nextLine();	

		System.out.print("▶비밀번호 입력 : ");
		String pw=ScanUtil.nextLine();
		
		
		
		Map<String, Object> result=dao.login(id,pw);
		
		pagNo=View.HOME;
		
		if(result==null) {
			System.out.println("\n[상태메세지]");
			System.out.println(" 로그인 오류입니다. 다시 입력하세요.\n");
			return pagNo;
		}else if(result.get("USERS_ID").equals(id)) {
			Controller.sessionStorage.put("login", true);
			Controller.sessionStorage.put("loginInfo", result.get("USERS_ID"));
			
			System.out.println("\n☆★☆★☆★☆★☆★☆★☆★☆★☆★☆"+result.get("USERS_NAME")+"님 환영합니다☆★☆★☆★☆★☆★☆★☆★☆★☆★☆");
			return View.USER_MENU;
		}else System.out.println("error");
		return pagNo;
	}
	
	
	//관리자 로그인
	public int adminLogin() {
		System.out.print("\n▶아이디 입력 : ");
		String id=ScanUtil.nextLine();
		System.out.print("▶비밀번호 입력 : ");
		String pw=ScanUtil.nextLine();
		
		Map<String, Object> result=dao.adminlogin(id,pw);
		
		pagNo=View.HOME;
		
		if(result==null) {
			System.out.println("\n[상태메세지]");
			System.out.println(" 로그인 오류입니다.\n");
			return pagNo;
		}else if(result.get("ADMIN_ID").equals(id)) {
			System.out.println("\n☆★☆★☆★☆★☆★☆★☆★☆★☆★☆"+result.get("ADMIN_NAME")+"님 환영합니다☆★☆★☆★☆★☆★☆★☆★☆★☆★☆");
			return View.ADMIN_MENU;
		}else System.out.println("dd");
		return pagNo;
	}
}
