package service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import controller.Controller;
import dao.ExerciseRcDAO;
import part.Abdomen;
import part.Arm;
import part.Back;
import part.Chest;
import part.Shoulder;
import part.LowerBody;
import util.PrintUtil;
import util.ScanUtil;
import util.View;

public class ExerciseRcService 
{
	private static ExerciseRcService instance = null;
	
	private ExerciseRcService() {}
	
	public static ExerciseRcService getInstance() 
	{
		if(instance == null) instance = new ExerciseRcService();
		return instance;
	}
	
	
	
	ExerciseRcDAO dao = ExerciseRcDAO.getInstance();
	
	Arm arm = new Arm(1,"팔","덤벨 컬","바벨 컬","킥 백","해머 컬","프리쳐 컬");
	Shoulder shoulder = new Shoulder(2,"어깨","밀리터리 프레스","덤벨 숄더 프레스","사이드 레터럴 레이즈","파이크 푸쉬업","덤벨 프론트 레이즈");
	Chest chest = new Chest(3,"가슴","푸쉬업","벤치 프레스","딥스","케이블 크로스오버","펙덱플라이");
	Abdomen abdomen = new Abdomen(4,"배","크런치","레그레이즈","싯업","플랭크","행잉 레그 레이즈");
	Back back = new Back(5,"등","풀업","랫 풀 다운","바벨 로우","케이블 로우","원암 덤벨 로우");
	LowerBody lowerBody = new LowerBody(6,"허벅지","스쿼트","런지","레그 컬","레그 익스텐션","레그 프레스");
	
	
	
	public int selectMenu()
	{
		System.out.println("\n============ 운동추천 화면입니다. 번호를 선택하세요. =============");
		System.out.println("1.추천 운동 조회");
		System.out.println("2.추천 운동 생성");
		System.out.println("3.추천 운동 삭제");
		System.out.println("0.메뉴로 가기");
		System.out.println("=====================================================");
		
		System.out.print("번호입력 >> ");
		int sel = Integer.parseInt(ScanUtil.nextLine());
		
		while(true)
		{
			switch(sel)
			{
				case 1:
					showExerciseList();
					break;
				case 2:
					setExcerciseList();
					break;
				case 3:
					delExerciseList();
					break;
				case 0:
					return View.USER_MENU;
				
				default:	
					System.out.println("\n[상태메세지]");
					System.out.println(" 번호를 다시 입력하세요.\n");
			
			}
			
			return View.EXERCISE_RECOMMAND_MENU;
		}
		
	}
	
	
	public int showExerciseList()
	{
		List<Map<String,Object>> result=null;
		
		
		System.out.println();
	
		
			result=dao.selectAll();
			if(result != null)
			{   System.out.println("\n[ 추천운동 목록 ]\n");
				PrintUtil.printf("|%15o| |%15o| |%15o| |%15o| |%15o| |%15o| |%15o|", " ", "회원 아이디", "팔", "어깨", "가슴", "배", "등","하체");
				System.out.println();
				System.out.println("=====================================================================================================================");
				for(int i=0; i<result.size(); i++) {
					PrintUtil.printf("|%11o| "," ",result.get(i).get("USERS_ID"));
					PrintUtil.printf("|%15o| "," ",result.get(i).get("HROU_ARM"));
					PrintUtil.printf("|%17o| "," ",result.get(i).get("HROU_SHOULDER"));
					PrintUtil.printf("|%15o| "," ",result.get(i).get("HROU_CHEST"));
					PrintUtil.printf("|%15o| "," ",result.get(i).get("HROU_ABDOMEN"));
					PrintUtil.printf("|%15o| "," ",result.get(i).get("HROU_BACK"));
					PrintUtil.printf("|%15o|"," ",result.get(i).get("HROU_LOWERBODY"));
					System.out.println();
										
				}System.out.println();
			}
			else
			{
				System.out.println("[상태메세지]\n 추천 운동이 설정되지 않았습니다.");
			}
				
				return View.EXERCISE_RECOMMAND_MENU;	
	}
	
	public int setExcerciseList() 
	{

		List<Object> param=new ArrayList<>
		(Arrays.asList(" "," "," "," "," "," "," "));
		
		System.out.println("\n===================운동 추천 리스트입니다.====================");
		System.out.println("1.팔");
		System.out.println("2.어깨");
		System.out.println("3.가슴");
		System.out.println("4.배");
		System.out.println("5.등");
		System.out.println("6.하체");
		System.out.println("0.뒤로가기");
		System.out.println("=====================================================");
		System.out.print("▶추천 받을 부위를 선택하세요(중복 선택 가능) >> "); 
		
		String sPartSel = ScanUtil.nextLine();  // 입력받은 수 하나씩 자름
		sPartSel = sPartSel.trim();//공백제거
		String[] sPartArr = sPartSel.split("");
			
		param.set(0,Controller.sessionStorage.get("loginInfo"));
//		System.out.println(Controller.sessionStorage.get("loginInfo"));
		for(int i= 0; i< sPartArr.length; i++)  // 입력받은 숫자에 해당하는 부위에 추천된 운동종목 대입
		{
			
			// 입력 값 처리방식 
			 if(!ScanUtil.isInteger(sPartArr[i])) 	// 입력값이 정수가 아니면
			 {
				 System.out.println("잘못 입력하셨습니다."); 
				 return View.EXERCISE_RECOMMAND_MENU;		  
			 }
			
			 else if(Integer.parseInt(sPartArr[i]) > 6)
			{
				System.out.println("잘못 입력했습니다. 처음으로 돌아갑니다.");
				return View.EXERCISE_RECOMMAND_MENU;
			}
			
			else if(Integer.parseInt(sPartArr[i])==0)
			{
				System.out.println("메인으로 돌아갑니다.");
				return View.USER_MENU;
			}
			
			else if(sPartArr[i].equals("1"))
			{
				param.set(Integer.parseInt(sPartArr[i]),arm.getRandomtype());
			}
			else if(sPartArr[i].equals("2"))
			{
				param.set(Integer.parseInt(sPartArr[i]),shoulder.getRandomtype());
			}
			else if(sPartArr[i].equals("3"))
			{
				param.set(Integer.parseInt(sPartArr[i]),chest.getRandomtype());
			}
			else if(sPartArr[i].equals("4"))
			{
				param.set(Integer.parseInt(sPartArr[i]),abdomen.getRandomtype());
			}
			else if(sPartArr[i].equals("5"))
			{
				param.set(Integer.parseInt(sPartArr[i]),back.getRandomtype());
			}
			else if(sPartArr[i].equals("6"))
			{
				param.set(Integer.parseInt(sPartArr[i]),lowerBody.getRandomtype());
			}
			
		}
		
		List<Object> id=new ArrayList<>();
		id.add(Controller.sessionStorage.get("loginInfo"));
		Map<String, Object> result=dao.selectCnt(id);
		Object val = result.get("COUNT(*)");
		String res = String.valueOf(val);
		
		if(res.equals("0")) 
		  {
			 dao.insertRcData(param);
			 System.out.println("\n추천 운동이 등록 되었습니다.");
		  }
		  else
		  {
			System.out.println("이미 데이터가 있습니다.");
		  }
		
		return View.EXERCISE_RECOMMAND_MENU;
	}
	
	public int delExerciseList()
	{
		List<Object> param=new ArrayList<>();
		String sel;

		while(true)
		{
			
			System.out.println("\n추천 운동을 삭제하시겠습니까?(Y|N)");
			
			sel = ScanUtil.nextLine().toUpperCase();
			
			List<Object> id=new ArrayList<>();
			id.add(Controller.sessionStorage.get("loginInfo"));
			Map<String, Object> result=dao.selectCnt(id);
			Object val = result.get("COUNT(*)");
			String res = String.valueOf(val);

			switch(sel)
			{
				case "Y" :
					if(res.equals("0")) 
					  {
						 System.out.println("삭제할 데이터가 없습니다");
					  }
					  else
					  {
						param.add(Controller.sessionStorage.get("loginInfo"));
						dao.deleteRcData(param);
						System.out.println("삭제완료");
					  }
						return View.EXERCISE_RECOMMAND_MENU;
	
				case "N" :
					System.out.println("메인으로 돌아갑니다");
					return View.USER_MENU;
		
				default :
					System.out.println("잘못 입력 했습니다");
			}
		}
		
	}

	
}



