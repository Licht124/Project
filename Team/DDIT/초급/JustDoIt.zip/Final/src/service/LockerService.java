package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import controller.Controller;
import dao.LockerDAO;
import util.ScanUtil;
import util.View;

public class LockerService 
{
   
   private static LockerService instance = null;
   private boolean[][] loc; // 락커 상태를 저장하는 멤버 변수
   
   private LockerService() {
      loc = new boolean[4][5];
   }
   
   public static LockerService getInstance() 
   {
      if(instance == null) instance = new LockerService();
      return instance;
   }

   LockerDAO dao = LockerDAO.getInstance();
   
   public int selectMenu()
   {
	  System.out.println("\n==============락커대여 화면입니다. 번호를 선택하세요.==============");
      System.out.println("1.락커 사용 조회");
      System.out.println("2.락커 대여");
      System.out.println("3.락커 반납");
      System.out.println("0.메뉴로 가기");
      System.out.println("=====================================================");
      
      System.out.print("메뉴를 선택하세요 >> "); 
      int sel = Integer.parseInt(ScanUtil.nextLine());
      
      while(true)
      {
         switch(sel)
         {
            case 1:
               showLockerList();
               break;
            case 2:
               useLocker();
               break;
            case 3:
               retLocker();
               break;
            case 0:
               return View.USER_MENU;
            
            default:   
               System.out.println("\n[오류메세지]");
               System.out.println("다시 입력하세요\n");
         }
         
         return View.LOCKER_MENU;
      }
      
   }
   
   
   public int showLockerList()
   {
     
       System.out.println("----------------");
       System.out.println("락커 사용 조회");
       System.out.println("----------------");

      
       List<Map<String, Object>> result = dao.selectLockerNo();
       List<Object> lockerNo = new ArrayList<>();
       result=dao.selectLocker();

       for(int l = 0 ; l < 20; l++)
       {
    	   lockerNo.add(l, "");
       }
       
       String lockeri;
       String lockerj;
       
       String changeNo;
    
       if(result != null)
		{
  			for(int i=0; i<result.size(); i++) 
  			{
  				changeNo = String.valueOf(result.get(i).get("LOCKER_NO")).substring(0,1);
  		      if(changeNo.equals("A"))
  			 {
  		    	changeNo = "0";
  		    	changeNo += String.valueOf(Integer.valueOf(String.valueOf(result.get(i).get("LOCKER_NO")).substring(1, 2)) - 1);
  		    	changeNo = changeNo.trim();

  		    	lockerNo.set(Integer.valueOf(changeNo.substring(1,2)),changeNo);
  			 }
  		      else if(changeNo.equals("B"))
 			 {
  		    	changeNo = "0";
  		    	changeNo += String.valueOf(Integer.valueOf(String.valueOf(result.get(i).get("LOCKER_NO")).substring(1, 2)) + 4 );
  		    	changeNo = changeNo.trim();
  		    	
  		    	lockerNo.set(Integer.valueOf(changeNo.substring(1,2)),changeNo);
 			 }
  		    else if(changeNo.equals("C"))
			 {
  		    	changeNo = "1";
  		    	changeNo += String.valueOf(Integer.valueOf(String.valueOf(result.get(i).get("LOCKER_NO")).substring(1, 2)) - 1);
  		    	changeNo = changeNo.trim();
  		    	
  		    	lockerNo.set(Integer.valueOf(changeNo),changeNo);
			 }
  		    else if(changeNo.equals("D"))
			 {
  		    	changeNo = "1";
  		    	changeNo += String.valueOf(Integer.valueOf(String.valueOf(result.get(i).get("LOCKER_NO")).substring(1, 2)) + 4);
  		    	changeNo = changeNo.trim();
  		    	
  		    	lockerNo.set(Integer.valueOf(changeNo),changeNo);
			 }
  		 
  			}
		}
       
  			
  		    
  
// 			for(int i=0; i<lockerNo.size(); i++) 
// 			{
// 				System.out.println(lockerNo.get(i));
//		
// 			}
  			
  			boolean bOn = false;
  			boolean bOn2 = false;
  			int useLeft = 0;
  			char use=1;
  			char row = 65;
  			
  			for (int i=0;i<loc[0].length;i++) 
  			{    
  			    System.out.print("  "+(use+i)+" "); 
  			}                             
  			System.out.println();
  			int k = 0;
  			for (int i=0; i<loc.length;i++) 
  			{
  			  System.out.print((char)(row+i)+" ");

  				 for (int j=0; j<loc[i].length ; j++) 
  				  {
  					if(String.valueOf(lockerNo.get(k)).equals("")) 
 					 {
 					 			System.out.print(" □ ");
 	  							useLeft++;
 	  							k++;
 					 }
  					else 
  					{

  							System.out.print(" ■ ");
  							k++;
  					}

  				  }
  				 System.out.println();
  			}

       

       System.out.println("● 잔여좌석 : "+useLeft);
       
       return View.LOCKER_MENU;   
   }
   
   public int useLocker() 
   { 
      
      Scanner scanner = new Scanner(System.in);

       System.out.println("----------------");
       System.out.println("락커 대여");
       System.out.println("----------------");

      
       String userId = (String) Controller.sessionStorage.get("loginInfo");
       List<Object> returnid = new ArrayList<>();
       returnid.add(userId);

       int res1 = dao.selUserLocker(returnid);
       
       if(res1 != 0)
       {
    	   System.out.println("이미 대여한 락커가 있습니다");
    	   return View.LOCKER_MENU;
       }
       

       // 락커 정보 출력
       showLockerList();

       System.out.print("대여할 락커의 행(A-D)과 열(1-5)을 입력하세요: ");
       String sel = scanner.nextLine(); // 대문자 변환 후 첫 글자 선택
       sel = sel.substring(0,1).toUpperCase() + sel.substring(1, 2);
 
       List<Map<String, Object>> res = dao.selectLockerNo();
       String lockerNo;
       if(res != null)
       {
	       for(int i = 0; i < res.size(); i++)
	       {
	    	   	lockerNo = String.valueOf(res.get(i).get("LOCKER_NO"));
	    	   if(sel.equals(lockerNo.trim()))
	    	   {
	    		   System.out.println("해당 락커는 이미 대여 중입니다.");
	               return View.LOCKER_MENU;
	    	   }
	       }
       }
     
       
       // 대여 정보 생성
       List<Object> rentInfo = new ArrayList<>();
       rentInfo.add(Controller.sessionStorage.get("loginInfo")); // 사용자 ID
       rentInfo.add(sel); // 락커 번호 (행 + 열)
       rentInfo.add("대여"); // 락커 사용 상태 

       // 락커 대여 정보 저장
       int result = dao.insertData(rentInfo);

       if (result > 0) {
           // 락커 상태 변경
           System.out.println("락커가 성공적으로 대여되었습니다.");
          
       } else {
           System.out.println("락커 대여 중 오류가 발생했습니다. 다시 시도해주세요.");
       }

       return View.LOCKER_MENU;
   }
   
   public int retLocker()
   {
      
          Scanner scanner = new Scanner(System.in);

          System.out.println("----------------");
          System.out.println("락커 반납");
          System.out.println("----------------");

          // 락커 정보 출력
          //showLockerList();

          System.out.print("락커를 반납하시겠습니까? (Y/N): ");
          String answer = scanner.nextLine().toUpperCase();

          if (answer.equals("Y"))
          {
              // 반납 정보 생성
              String userId = (String) Controller.sessionStorage.get("loginInfo");
              List<Object> returnInfo = new ArrayList<>();
              returnInfo.add(userId);

              // 락커 반납 정보 삭제
              int result = dao.deleteReturnedLocker(returnInfo);

              if (result > 0) {
                  System.out.println("락커가 성공적으로 반납되었습니다.");
                  
            
              } else 
              {
                  System.out.println("이미 처리되었습니다");
              }
          }
          else if (answer.equals("N")) 
          {
              System.out.println("락커 반납이 취소되었습니다.");
          } 
          else 
          {
              System.out.println("잘못된 입력입니다.");
          }   

          return View.LOCKER_MENU;
   
   }

   
}

