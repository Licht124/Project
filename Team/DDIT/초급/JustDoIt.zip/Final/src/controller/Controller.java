package controller;

import java.util.HashMap;
import java.util.Map;

import service.AdminService;
import service.BuyService;
import service.ExerciseRcService;
import service.LoginService;
import service.UserService;
import service.LockerService;
import service.BmiCalService;
import util.ScanUtil;
import util.View;

public class Controller {
	// 세션
	public static Map<String, Object> sessionStorage = new HashMap<>();
	
	//////
	LoginService loginService = LoginService.getInstance();
	ExerciseRcService excerciseRcService = ExerciseRcService.getInstance();
	BuyService buyService = BuyService.getInstance();
	
	UserService userService=UserService.getInstance();
	AdminService adminService=AdminService.getInstance();
	LockerService lockerService = LockerService.getInstance();
	BmiCalService bmiCalService = BmiCalService.getInstance();
	
	public static void main(String[] args)
	{
		new Controller().start();
	}
	
	private void start() {
		sessionStorage.put("login", false);	// false: 로그인 안됨
		sessionStorage.put("loginInfo", null);
		int view = View.HOME;
		while(true) {
			switch (view)
			{
			
			case View.HOME: 
				view = home(); 
				break;
				
			case View.ADMIN_LOGIN:
				view=loginService.adminLogin();
				break;
				
			case View.ADMIN_MENU:
				view=adminService.loginMenu();
				break;	
				
			case View.ADMIN_USERLIST:
				view=adminService.userList();
				break;
				
			case View.ADMIN_EDITUSER:
				view=adminService.editUser();
				break;

			case View.ADMIN_EDITINFO:
				view=adminService.editInfo();
				break;
				
			case View.ADMIN_SALES:
				view=adminService.sales();
				break;
				
			case View.ADMIN_SALES_DETAIL:
				view=adminService.salesDetail();	
				break;
				
			case View.ADMIN_STOCK:
				view=adminService.stock();	
				break;

			case View.USER_LOGIN:
				view=loginService.login();
				break;
				
			case View.USER_MENU:
				view=userService.loginMenu();
				break;
				
			case View.USER_SIGNUP:
				view= userService.signUp();
				break;
	
				
			case View.EXERCISE_RECOMMAND_MENU: 
				view = excerciseRcService.selectMenu();
				break;

			case View.BUY_MENU:
				view = buyService.selectMenu();
				break;

			case View.LOCKER_MENU: 
				view = lockerService.selectMenu();
				break;
				
			case View.BMI_MENU:
				view = bmiCalService.calBmi();
				break;
		
			}
		}
	}

	private int home() 
	{

		printDesign();
		System.out.println("=================== 헬스장 관리 프로그램 ====================");
		System.out.println("1.관리자로그인 \n2.회원로그인  \n9.회원가입 \n0.종료");
		System.out.println("=====================================================");
		System.out.print("번호입력 >> ");
		
		switch (ScanUtil.nextInt()) {
		case 1:
			return View.ADMIN_LOGIN;
		case 2:
			return View.USER_LOGIN;
		case 9:
			return View.USER_SIGNUP;
		case 0:
			System.out.println("프로그램을 종료합니다.");
			System.exit(0);			
		default: 
			System.out.println("\n[오류메세지]");
			System.out.println(" 번호를 다시 입력하세요.\n");
			return View.HOME;
		}
		
	}
	
	public void printDesign()
	{
	      System.out.println("                                       .-;.                                                             ");
	      System.out.println("                                      -$@@=,                                                          "); 
	      System.out.println("                                    .~#@@@@=:                                                          "); 
	      System.out.println("                                   -*@@@@@@@@*                                                         "); 
	      System.out.println("                                  -$@@@@@@@@@@*                                                        "); 
	      System.out.println("                                 ;#@@@@@@@@@@@@~                                                       "); 
	      System.out.println("                                 -@@@@@@@@@@@@@#                                                       "); 
	      System.out.println("                                 .#@@@@@@@@@@@@@$.                                                     "); 
	      System.out.println("                                  ,#@@@@@@@@@@@@@*                  ██╗██╗   ██╗███████╗████████╗        "); 
	      System.out.println("                                   :@@@@@@@@@@@@@$,                 ██║██║   ██║██╔════╝╚══██╔══╝      "); 
	      System.out.println("                                   ,=@@@@@@@@@@@@@;                 ██║██║   ██║███████╗   ██║         "); 
	      System.out.println("                             -!.    ,$@@@@@@@@@@@@$-           ██   ██║██║   ██║╚════██║   ██║         "); 
	      System.out.println("                            ~#@$    :@@@@@@@@@@@@@@~           ╚█████╔╝╚██████╔╝███████║   ██║        "); 
	      System.out.println("                            :@@@. -#@@@@@@@@@@@@@@@~            ╚════╝  ╚═════╝ ╚══════╝   ╚═╝         "); 
	      System.out.println("                         .@@!;@$.   ;@@@@@@@@@@@@@@@                                                   "); 
	      System.out.println("                       .,=@@;.,,$@@@!~#@@@@@@@@@@@@@,                                                  "); 
	      System.out.println("                      ,$@ =@!!@@@@@@@;!*=@@@@@@@@@@$,                                                  "); 
	      System.out.println("                      !@@;.@=;*@@@@@@@,  *@@@@@@@@=-                                                   "); 
	      System.out.println("                      -#@@!;@=-~::!@@@*  ,#@@@@@#!,            ██████╗  ██████╗                        ");
	      System.out.println("            .;     .*=~=@@#-!@-;==!!@@@=  ;@@@@@-              ██╔══██╗██╔═══██╗                       ");
	      System.out.println("           .#@;    ,@@#~#@@* .-#@#~#@@@@   !@@$.               ██║  ██║██║   ██║                       ");
	      System.out.println("          #@@@@:   ,@@@- @@=:@@@@.@@@@@@   .=,                 ██║  ██║██║   ██║                       ");
	      System.out.println("        .$@@@@@#,   -##~..,-$@#*.#@@@@@=                       ██████╔╝╚██████╔╝                       ");
	      System.out.println("      .!@@@@@@@@;   ---$@#!@@$- *@@@@@@                        ╚═════╝  ╚═════╝                        ");
	      System.out.println("     .*@@@@@@@@@@;,;@@@@@@@$!;,,@@@@@@#                                                                  ");
	      System.out.println("     ,@@@@@@@@@@@@=@@@@@@@#~-$~!@@@@@@$                                                                  ");
	      System.out.println("     ,@@@@@@@@@@@@@@@@@@@:~*$@~~@@@@@@@                                                                  ");
	      System.out.println("      ;@@@@@@@@@@@@@@@@@- $@@@#.@@@@@@@$                                                               ");
	      System.out.println("      ~@@@@@@@@@@@@@@@=, @@@@@@,@@@@@@@@$                      ██╗████████╗██╗██╗                       ");
	      System.out.println("      ~@@@@@@@@@@@@@@!    @@@@@@@@@@@@@@#.                     ██║╚══██╔══╝██║██║                       ");
	      System.out.println("       ;@@@@@@@@@@@@@*.   =$#@@@@@@@@@@@@$.                    ██║   ██║   ██║██║                       ");
	      System.out.println("       ~#@@@@@@@@@@@@@:     -#@@@@@@@@@@@@=.                   ██║   ██║   ╚═╝╚═╝                       ");
	      System.out.println("        !@@@@@@@@@@@@@*.     ~#@@@@@@@@@@@@~                   ██║   ██║   ██╗██╗                       ");
	      System.out.println("        ,#@@@@@@@@@@@@@=.     =@@@@@@@@@@@@$,                  ╚═╝   ╚═╝   ╚═╝╚═╝                        ");
	      System.out.println("         ,#@@@@@@@@@@@@@~     ,#@@@@@@@@@@@@$.                                                           ");
	      System.out.println("          -@@@@@@@@@@@@@@      .@@@@@@@@@@@@@-                                                           ");
	      System.out.println("           *@@@@@@@@@@@#.       @@@@@@@@@@@@@@                                                           ");
	      System.out.println("            *@@@@@@@@@~          #@@@@@@@@@@@!                                                           ");
	      System.out.println("             ;#@@@@@=~           .#@@@@@@@@#~                                                            ");
	      System.out.println("              -$@@@;              ;@@@@@@@$-                                                            ");
	      System.out.println("               -;!:               .*@@@@@;-                                                              ");
	      System.out.println("                                   ,=@@!-                                                                ");
	      System.out.println("                                    ;:,                                								  ");
		
		
	}
	
}
