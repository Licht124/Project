package part;

public class LowerBody extends Part
{

	public LowerBody(int partNo,String partName, String type1, String type2, String type3, String type4, String type5)
	{
		super(partNo,partName, type1, type2, type3, type4, type5);
	}
	
}
