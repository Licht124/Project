package part;

public class Part 
{

	int partNo;
	String partName;
	String type1;
	String type2;
	String type3;
	String type4;
	String type5;
	

	public Part(int partNo,String partName, String type1, String type2, String type3, String type4, String type5)
	{
		this.partNo = partNo;
		this.partName = partName;
		this.type1 = type1;
		this.type2 = type2;
		this.type3 = type3;
		this.type4 = type4;
		this.type5 = type5;

	}
	
	
	public String getRandomtype()
	{
			int rand = (int)((Math.random() * 5)+1);
			if(rand == 1)
			{
				return this.type1;
			}
			else if(rand == 2)
			{
				return this.type2;
			}
			else if(rand == 3)
			{
				return this.type3;
			}
			else if(rand == 4)
			{
				return this.type4;
			}
			else if(rand == 5)
			{
				return this.type5;
			}
			else
				return this.type1;
	}


	
	
	

}