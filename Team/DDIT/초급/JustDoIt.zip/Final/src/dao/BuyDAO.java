package dao;

import java.util.List;
import java.util.Map;

import controller.Controller;
import util.JDBCUtil;

public class BuyDAO {
	private static BuyDAO instance = null;

	private BuyDAO() {
	}

	public static BuyDAO getInstance() {
		if (instance == null)
			instance = new BuyDAO();
		return instance;
	}

	JDBCUtil jdbc = JDBCUtil.getInstance();

	public List<Map<String, Object>> selectMenu() {
		return jdbc.selectList(" SELECT * FROM CAT ");
	}

	public List<Map<String, Object>> selTicket() {
		return jdbc.selectList(" SELECT PROD_NO,PROD_NAME, PROD_PRICE from prod where cat_no = 1 order by prod_no ");
	}

	public List<Map<String, Object>> selTool() {
		return jdbc.selectList(
				" select * from prod where cat_no = 2 order by prod_no ");
	}

	public List<Map<String, Object>> selFood() {
		return jdbc.selectList(
				" select * from prod where cat_no = 3 order by prod_no ");
	}
	
	public int insertBuyData (List<Object> param) {
		String sql = "INSERT ORDERS (USERS_ID, ORDERS_DATE, ORDERS_PRICE, ORDERS_PAYOPTION, ORDERS_STATUS)"
				+ "VALUES(USERS_ID, SYSDATE, ?, ?, ?, ?)";
		
		return jdbc.update(sql, param);
	}
	
	public int ShowBuyList(List<Object>param) {
		/*
		 * String sql =
		 * "SELECT a.users_id, b.orders_date, b.orders_price, b.orders_status, b.orders_payoption"
		 * + "FROM users a, ORDERS b " + "where a.users_id = b.users_id " +
		 * "order by a.users_id";
		 * 
		 * return jdbc.update(sql, param);
		 */
		return 0;
	}
	
	public List<Map<String, Object>> selectAll()  // 현재 로그인 아이디의 루틴 정보 출력
	{

		String sql;
		String id;
		id = (String)Controller.sessionStorage.get("loginInfo"); // 로그인 정보 저장
		
		sql ="SELECT * FROM ORDERS WHERE USERS_ID = ";
		
		sql += "'" +id + "'";
		//System.out.println(sql);
		
		return jdbc.selectList(sql);
		
	}
	
	public List<Map<String, Object>> selectOrders() 
	{

		  String sql="SELECT * FROM ORDERS";
	      return jdbc.selectList(sql);
	}
	
	public Map<String, Object> selectCnt() 
	{

		  String sql="SELECT COUNT(*) FROM ORDERS";
	      return jdbc.selectOne(sql);
	}
	
	
	
	public int insOrderData(List<Object> param) 
	{
	
		   String sql="INSERT INTO ORDERS(ORDERS_NO,USERS_ID, ORDERS_DATE, ORDERS_PRICE,ORDERS_STATUS, ORDERS_PAYOPTION) ";
	       sql=sql+" VALUES(?,?, ?, ?, ?, ?) "; 
	    
	       return jdbc.update(sql, param);
	}
	

	public int insOrderDetData(List<Object> param) 
	{
	
		   String sql="INSERT INTO ORDERDET(ORDERDET_NO,ORDERS_NO, PROD_NO, ORDERDET_QTY,ORDERDET_PRICE) ";
	       sql=sql+" VALUES(?,?, ?, ?, ?) "; 
	    
	       return jdbc.update(sql, param);
	}

	
	public int updateProdStockData(List<Object> param) 
	{

		   String sql="UPDATE PROD SET PROD_STOCK = ? WHERE PROD_NO = ?";
		   
	       return jdbc.update(sql, param);

	}
	
}
