package dao;

import java.util.List;
import java.util.Map;

import controller.Controller;
import util.JDBCUtil;
import util.ScanUtil;

public class ExerciseRcDAO {
	
	private static ExerciseRcDAO instance = null;
	
	private ExerciseRcDAO()
	{
	}
	public static ExerciseRcDAO getInstance()
	{
		if (instance == null)
			instance = new ExerciseRcDAO();
		return instance;
	}

	JDBCUtil jdbc = JDBCUtil.getInstance();
	
	
	public List<Map<String, Object>> selectAll()  // 현재 로그인 아이디의 루틴 정보 출력
	{
		
		String sql;
		String id;
		id = (String)Controller.sessionStorage.get("loginInfo"); // 로그인 정보 저장
		
		sql ="SELECT * FROM HROU WHERE USERS_ID = ";
		
		sql += "'" +id + "'";
		//System.out.println(sql);
		
		return jdbc.selectList(sql);
	}
	
	public Map<String, Object> selectCnt(List<Object> param) 
	{

		  String sql="SELECT COUNT(*) FROM HROU WHERE USERS_ID = ?";
	
	       return jdbc.selectOne(sql,param);

	}
	
	public int insertRcData(List<Object> param) 
	{
	
		   String sql="INSERT INTO HROU(USERS_ID,HROU_ARM, HROU_SHOULDER, HROU_CHEST,HROU_ABDOMEN, HROU_BACK, HROU_LOWERBODY) ";
	       sql=sql+" VALUES(?,?, ?, ?, ?, ?, ?) "; 
	    
	       return jdbc.update(sql, param);

	}
	
	public int deleteRcData(List<Object> param) 
	{
		String sql="DELETE FROM HROU WHERE USERS_ID = ? ";

	     return jdbc.update(sql, param);
		
	}
	

	
	
}
