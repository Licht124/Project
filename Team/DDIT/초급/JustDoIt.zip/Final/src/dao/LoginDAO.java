package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.JDBCUtil;

// 데이터베이스로 쿼리를 날려서 결과를 얻는다.
public class LoginDAO {
	// 싱글톤 패턴을 만든다.
	private static LoginDAO instance = null;
	private LoginDAO() {}
	public static LoginDAO getInstance() 
	{
		if(instance == null) 
			instance = new LoginDAO();
		return instance;
	}
	
	// JDBC를 부른다.
	JDBCUtil jdbc = JDBCUtil.getInstance();
	
	//회원로그인
	public Map<String, Object> login(String id, String pw) {
		String sql="SELECT * FROM USERS WHERE USERS_ID = ? AND USERS_PW = ?";
		List<Object> param=new ArrayList<Object>();
		param.add(id);
		param.add(pw);
		
		return jdbc.selectOne(sql, param);
	}
	
	//관리자로그인
	public Map<String, Object> adminlogin(String id, String pw) {
		String sql="SELECT * FROM ADMIN WHERE ADMIN_ID = ? AND ADMIN_PW = ?";
		List<Object> param=new ArrayList<Object>();
		param.add(id);
		param.add(pw);
		
		return jdbc.selectOne(sql, param);
	}
}
