package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import util.JDBCUtil;

public class AdminDAO {
	private static AdminDAO instance=null;
	private AdminDAO() {}
	public static AdminDAO getInstance() {
		if(instance==null) instance=new AdminDAO();
		return instance;
	}
	
	JDBCUtil jdbc=JDBCUtil.getInstance();
	
	// 관리자 로그인
	public Map<String, Object> adminLogin(String id, String pw){
		return jdbc.selectOne("SELECT * FROM ADMIN"+ " WHERE ADMIN_ID='"+id+"' AND ADMIN_PW='"+pw+"' ");
	}
	
	// 회원 전체조회
	public List<Map<String, Object>> userList(){
		String sql = "SELECT * FROM USERS";
		return jdbc.selectList(sql);
	}
	
	// 회원 전체조회(NUMBER)
	public List<Map<String, Object>> userListNum(){
		String sql = "SELECT ROW_NUMBER() OVER(ORDER BY USERS_ID) NUM, A.* FROM USERS A";
		return jdbc.selectList(sql);
	}
	
	// 회원 아이디로조회
	public Map<String, Object> userListID(String id){
		return jdbc.selectOne("SELECT * FROM USERS WHERE USERS_ID='"+id+"'");
	}
	
	// 회원정보 수정
	public int edit(List<Object> param) {
		String sql = "UPDATE USERS SET USERS_NAME = ?, USERS_EMAIL = ?, USERS_PHONE = ?, USERS_GENDER = ?  WHERE USERS_ID = ?";
		return jdbc.update(sql,param);
	}
	
	// 회원정보 삭제
		public int delete(List<Object> param) {
			String sql = "DELETE FROM USERS WHERE USERS_ID=?";
			return jdbc.update(sql,param);
		}

	// 매출조회
	public Map<String, Object> total() {
		String sql = "SELECT SUM(ORDERS_PRICE) FROM ORDERS";
		return jdbc.selectOne(sql);
		}	
	
	public Map<String, Object> todayTotal() {
		String sql = "SELECT SUM(ORDERS_PRICE) FROM ORDERS WHERE ORDERS_DATE LIKE TO_DATE(SYSDATE,'YY/MM/DD')";
		return jdbc.selectOne(sql);
	}
	
	// 매출조회-카테고리	
	public Map<String, Object> catTotal1(){
		String sql="SELECT SUM(ORDERDET_PRICE) FROM ORDERDET WHERE SUBSTR(PROD_NO,1,1)=1";
		return jdbc.selectOne(sql);
	}
	public Map<String, Object> catTotal2(){
		String sql="SELECT SUM(ORDERDET_PRICE) FROM ORDERDET WHERE SUBSTR(PROD_NO,1,1)=2";
		return jdbc.selectOne(sql);
	}
	public Map<String, Object> catTotal3(){
		String sql="SELECT SUM(ORDERDET_PRICE) FROM ORDERDET WHERE SUBSTR(PROD_NO,1,1)=3";
		return jdbc.selectOne(sql);
	}
	
	// 매출조회-상품별
	public List<Map<String, Object>>  detailTotal(List<Object> param){
		String sql=
				"SELECT A.PROD_NO, A.PROD_NAME, SUM(NVL(B.ORDERDET_QTY,0)) 판매수량, SUM(NVL(B.ORDERDET_PRICE,0)) 판매금액\r\n" + 
				"FROM PROD A\r\n" + 
				"LEFT JOIN ORDERDET B ON(A.PROD_NO=B.PROD_NO)\r\n" + 
				"WHERE SUBSTR(A.PROD_NO,1,1)=?\r\n" + 
				"GROUP BY A.PROD_NO, A.PROD_NAME ORDER BY A.PROD_NO";		
//	List<Object> param=new ArrayList<Object>();
//	param.add(num);
		return jdbc.selectList(sql, param);
	}	

		
}
