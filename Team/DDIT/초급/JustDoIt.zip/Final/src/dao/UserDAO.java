package dao;

import java.util.List;
import java.util.Map;

import util.JDBCUtil;

public class UserDAO {
	private static UserDAO instance=null;
	private UserDAO() {}
	public static UserDAO getInstance() {
		if(instance==null) instance=new UserDAO();
		return instance;
	}
	
	JDBCUtil jdbc=JDBCUtil.getInstance();
	
	 //회원 로그인
//		public Map<String, Object> login(String id, String pw){
//			return jdbc.selectOne("SELECT * FROM USERS"
//					+ " WHERE USERS_ID='"+id+"' AND USERS_PW='"+pw+"' ");
//		}

	//회원가입
		public int signUp(List<Object> param) {
			return jdbc.update( "INSERT INTO USERS ( USERS_ID, USERS_PW, USERS_NAME, USERS_EMAIL, USERS_PHONE, USERS_GENDER ) VALUES (?, ?, ?, ?, ?, ?)", param);
		}
	
}
	
	
	


