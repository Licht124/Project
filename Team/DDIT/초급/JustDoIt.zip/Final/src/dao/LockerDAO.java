package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import controller.Controller;
import util.JDBCUtil;
import util.ScanUtil;

public class LockerDAO {

    private static LockerDAO instance = null;

    private LockerDAO() {
    }

    public static LockerDAO getInstance() {
        if (instance == null)
            instance = new LockerDAO();
        return instance;
    }

    JDBCUtil jdbc = JDBCUtil.getInstance();

    
    public List<Map<String, Object>> selectLockerNo() {
        String sql;
      
        sql = "SELECT LOCKER_NO FROM LOCKER";
        
        return jdbc.selectList(sql);
    }

    
    
    
    public List<Map<String, Object>> selectLocker() {
        String sql;
     
        sql = "SELECT * FROM LOCKER";

        return jdbc.selectList(sql);
    }

    public Map<String, Object> selectOne() {
        String sql = "SELECT COUNT(*) FROM LOCKER";

        return jdbc.selectOne(sql);
    }
    public int insertData(List<Object> param) {
        String sql = "INSERT INTO LOCKER(USERS_ID, LOCKER_NO, LOCKER_USE) VALUES(?, ?, ?)";
        return jdbc.update(sql, param);
    }
    
    public int deleteReturnedLocker(List<Object> param) {
        String sql = "DELETE FROM LOCKER WHERE USERS_ID = ?";
        return jdbc.update(sql, param);
    }
    

    public int selUserLocker(List<Object> param) {
        String sql = "SELECT * FROM LOCKER WHERE USERS_ID = ?";
        return jdbc.update(sql, param);
    }
    
    
    
    
    

    
}