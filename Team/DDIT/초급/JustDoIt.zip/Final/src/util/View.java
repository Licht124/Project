package util;

public interface View {
	
	
		int HOME = 1;
		int MAIN = 11;
	
	//회원
		int USER_LOGIN = 21;
		int USER_SIGNUP = 22;
		int USER_MENU = 23;
		int USER = 24;
		int USER_RESIGN = 25;
		
	//관리자
		int ADMIN_LOGIN = 31;
		int ADMIN_MENU = 32;
		int ADMIN_USERLIST = 33;
		int ADMIN_EDITUSER = 34;
		int ADMIN_EDITINFO = 35;
	
		
		int ADMIN_SALES = 36;
		int ADMIN_SALES_DETAIL = 37;
		int ADMIN_STOCK = 38;

		
		
		int EXERCISE_RECOMMAND_MENU = 41;
		
		int LOCKER_MENU = 51;

		int BUY_MENU = 61;
		
		int BMI_MENU = 72;


	
	
	


//기타
	int HROU = 99;
}
